function authLogin() {
    var username = $('#login-form-username').val();
    var password = $('#login-form-password').val();
    var flag = 0;

    if (username == "") {
        $("#login-form-username").css("border", "1px solid red");
    } else {
        $("#login-form-username").css("border", "none");
        flag += 1;
    }

    if (password == "") {
        $("#login-form-password").css("border", "1px solid red");
    } else {
        $("#login-form-password").css("border", "none");
        flag += 1;
    }

    // swal('Berhasil', 'Data Berhasil Dimasukkan', 'success').then((data) => {

    // });
    // if (flag == 2) {
    //     var data = {
    //         username: username,
    //         password: password
    //     };
    //     jQuery.ajax({
    //         type: 'post',
    //         "url": "auth",
    //         data: data,
    //         dataType: 'json',
    //         beforeSend: function() {

    //         },
    //         success: function(response) {

    //         },
    //         error: function(xhr, ajaxOptions, thrownError) {

    //         },
    //         complete: function(response) {

    //         }
    //     });
    // }
}

$(document).ready(function() {

});